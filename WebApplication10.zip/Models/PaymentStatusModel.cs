﻿namespace WebApplication10.Models
{
    public class PaymentStatusModel
    {
        public string OrderId { get; set; }
        public string Status { get; set; }
    }
}
